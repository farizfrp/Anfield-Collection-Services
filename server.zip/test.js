
const MongoClient = require('mongodb').MongoClient;
const longUri='mongodb://anfield1:Smpn21bekasi@cluster0-shard-00-00-2ijjv.mongodb.net/test?ssl=true&authMechanism=SCRAM-SHA-1&authSource=admin&retryWrites=true&w=majority';
const uri = "mongodb+srv://anfield1:Smpn21bekasi@cluster0-2ijjv.mongodb.net/test?retryWrites=true&w=majority";
const client = new MongoClient(longUri, { useNewUrlParser: true });
client.connect(err => {
  console.log("Error Broo",err)
 // const collection = client.db("test").collection("devices");
  // perform actions on the collection object
  client.close();
});
